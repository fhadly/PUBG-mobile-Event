<?php
$emailku = 'masukan emailmu'; // GANTI EMAIL KAMU DISINI
?>