<!-- Ganti menjadi email mu disini-->
<!-- Ingat JANGAN GANTI COPYRIGHT SC-->
<?php
$emailku = 'email kamu@gmail.com';
?>

